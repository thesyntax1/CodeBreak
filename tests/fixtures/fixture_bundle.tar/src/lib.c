tar member text payload for codebreak.
